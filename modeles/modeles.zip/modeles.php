<?php 
require_once ('db_connect.php');
if (!function_exists('remplir')) {
	function remplir($nomDossier){
		$dossier = scandir('img/'.$nomDossier );
		$newDossier = array();
		for($i=0;$i < count($dossier);$i++){
			if ($i > 1) {
				array_push($newDossier, $dossier[$i]);
			}
		}

		return $newDossier;
	}


}

if (!function_exists('logique')) {
	function logique(){
		global $pdo;
		$remplir = remplir('');

		foreach ($remplir as $value) {

			$table = $value;
			$remplir = remplir($value);

			foreach ($remplir as $value) {

					$query = $pdo->query("SELECT img_$table FROM $table WHERE  img_$table = '".$value. "'");

					if($query->rowCount() < 1){

						$query = $pdo -> exec("INSERT INTO $table(id_$table, img_$table) VALUES('','img/".$table."/".$value."')");
	
					}

				}
			}
				
				
	}

}

logique();
	



